import time
import pandas as pd
import matplotlib.pyplot as plt 

# Defining the available data sets & their associated file names:
CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }



# Defining a function to load the data:
def loading_func(cities):
    
    """
    Asks for which dataset to lead.
    
    Args:
    (dict) the dictionary containing city names & their associated files.
    
    Returns:
    (pandas dataframe) the required data set.
    """

    while True:
        # Asking for city name:
        print('\nYou can load the dataset for: Chicago, New York City or Washington.')
        city = input('Enter city name: ').strip().title()

        # Confirming city name:
        confirm_msg = input(f'''
You are loading the dataset for {city},
To confirm the city name press enter,
To change it enter the new name: ''').strip().title()

        # Assigning the city name:
        if confirm_msg:
            city = confirm_msg

        # Handling errors:
        try:
            file_name = cities[city]

        except:
            print('\nSomething went wrong! Make sure to type city name correctrly!')

        else:
            # Loading data:
            print(f'\nLoading data for {city}..')
            folder = './data/'
            df = pd.read_csv(folder+file_name, parse_dates=['Start Time', 'End Time']).drop(columns='Unnamed: 0')
            print('Done!')

            # Renaming columns for more convenience:
            df.rename(columns=lambda x:x.strip().lower().replace(' ', '_'), inplace=True)

            # Creating the necessary extra columns:
            df['start_day'] = df['start_time'].dt.strftime('%A')
            df['start_month'] = df['start_time'].dt.strftime('%B')
            df['start_hour'] = df['start_time'].dt.strftime('%H')
            df['start_to_end'] = 'from ' + df['start_station'] + ' to ' + df['end_station']

            # Ending the loop
            break
            
    return city, df


def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')

    
    # get user input for city ('chicago', 'new york city', 'washington')
    city=input("Would you like to see data for chicago, new york city, or washington?\n").lower()
    
    cities_list=CITY_DATA.keys()
    while city not in cities_list :
        city = input("Please, You should choose one of those cities: 'Chicago', 'New York City', or 'Washington'.\n").lower()

    # get user input for filter value type ('month','day','all','none')
    filter_value=input("Would you like to filter the data by month, day, or not at all? type 'None' for no time filter.\n").lower()

    filter_list=['month','day','all','none']
    while filter_value not in filter_list:
        filter_value=input("Please, You should choose one of those filter values: 'month', 'day', 'all' or 'none'\n").lower()
    
    # get user input for month (all, january, february, ... , june)
    months_list=['january', 'february', 'march', 'april', 'may', 'june']
    if filter_value == 'month' or filter_value == 'all' :
        month=input("Would you like to see data for Which month - 'january', 'february', 'march', 'april', 'may', 'june'?\n").lower()   
        while month not in months_list:
            month=input("please, You should choose one of those months: 'january', 'february', 'march', 'april', 'may', 'june'\n").lower() 
    else:
        month='all'

    # get user input for day of week (all, monday, tuesday, ... sunday)
    days_list=['saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday']
    if filter_value == 'day' or filter_value == 'all' :
        day=input("Would you like to see data for Which day - ''saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday'?\n").lower()     
        while day not in days_list:
            day=input("please, You should choose one of those days: 'saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday'\n").lower() 
    else:
        day='all' 
    

    print('#'*50)
    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    #load the data depending on the entered city from user to dataframe 
    df=pd.read_csv(CITY_DATA[city])

    # convert 'Start Time' column to datetime type 
    df['Start Time']=pd.to_datetime(df['Start Time'])

    #create two new columns (Month and Day Of Week) to hold months and days of week of 'Start Time'
    df['Month']=df['Start Time'].dt.month
    df['Day Of Week']=df['Start Time'].dt.day_name()

    #filtering the 'Month' column 
    if month != 'all':
        # return the index of month (start January = 1)
        months_list=['january', 'february', 'march', 'april', 'may', 'june']
        month=months_list.index(month)+1
        df = df[df['Month'] == month]

    #filtering the 'Day Of Week' column 
    if day != 'all':
        df = df[df['Day Of Week'] == day.title()]

    return df
   


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    common_month=df['Month'].mode()[0]
    print("\nThe most common month in the data is : {}".format(common_month))

    # display the most common day of week
    common_day=df['Day Of Week'].mode()[0]
    plt.plot(common_day, marker = '*', color = 'r' )
    plt.show()
    print("\nThe most common day of week in the data is : {}".format(common_day))

    # display the most common start hour
    df['Hour'] = df['Start Time'].dt.hour
    common_start_hour=df['Hour'].mode()[0]
    plt.plot(common_start_hour, marker = '*', color = 'r' )
    plt.show()
    print("\nThe most common start hour in the data is : {}".format(common_start_hour))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('#'*50)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most commonly used start station
    common_start_station = df['Start Station'].mode()[0]
    plt.plot(common_start_station, marker = '*', color = 'r' )
    plt.show()
    print("\nThe most common start station in the data is : {}".format(common_start_station))

    # display most commonly used end station
    common_end_station = df['End Station'].mode()[0]
    plt.plot(common_end_station, marker = '*', color = 'r' )
    plt.show()
    print("\nThe most common end station in the data is : {}".format(common_end_station))

    # display most frequent combination of start station and end station trip
    df['Trip'] = df['Start Station'] + "to" + df['End Station']
    common_trip = df['Trip'].mode()[0]
    plt.plot(common_trip, marker = '*', color = 'r' )
    plt.show()
    print("\nThe most common trip between start station and end station in the data is : {}".format(common_trip))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('#'*50)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time    
    df['Travel Time']=pd.to_datetime(df['End Time'])-pd.to_datetime(df['Start Time'])
    total_travel_time = df['Travel Time'].sum()

    num_days =  total_travel_time.days
    num_hours = (total_travel_time.seconds) // (60*60)
    num_minutes = (total_travel_time.seconds % (60*60)) // 60
    num_seconds = (total_travel_time.seconds % (60*60)) % 60

    #Total travel time is: 3250 days 21 hours 56 minutes 27 seconds
    print("Total travel time is: {} days {} hours {} minutes {} seconds".format(num_days,num_hours,num_minutes,num_seconds))


    # display mean travel time
    average_travel_time = df['Travel Time'].mean()
    
    num_days =  average_travel_time.days
    num_hours = (average_travel_time.seconds) // (60*60)
    num_minutes = (average_travel_time.seconds) % (60*60) // 60
    num_seconds = (average_travel_time.seconds) % (60*60) % 60

    #Total travel time is: 3250 days 21 hours 56 minutes 27 seconds
    print("Average travel time is: {} days {} hours {} minutes {} seconds".format(num_days,num_hours,num_minutes,num_seconds))


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('#'*50)


def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    user_types_counts=df['User Type'].value_counts()
    print("The counts of user types are : {}".format(user_types_counts))


    # Display counts of gender
    #check on the value of 'Gender' column
    if 'Gender' in df.columns:
        gender_counts=df['Gender'].value_counts()
        print("The counts of gender types are : {}".format(gender_counts))
    else:
        print("No gender information in this city.")

    # Display earliest, most recent, and most common year of birth
    #check on the value of 'Birth Year' column
    if 'Birth Year' in df.columns:
        birth_year = df['Birth Year'].fillna(0).astype('int64')
        earliest=birth_year.min()
        recent=birth_year.max()
        common=birth_year.mode()[0]
        print("The earliest birth year is {} , the recent birth year is {} and the common birth year is {}".format(earliest,recent,common))   
    else:
        print("No Birth Year information in this city.")


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('#'*50)

def display_raw_data(df):
    """Ask the user if he wants to display the raw data and print 5 rows at time"""
    view_data = input("Would you like to view 5 rows of individual trip data? Enter yes or no?")
    start_loc = 0
    while (view_data.lower() == 'yes'):
        print(df.iloc[start_loc:start_loc+5])
        start_loc += 5
        view_display = input("Do you wish to continue?: ").lower()
        if view_display.lower() != 'yes':
            break
        

def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)
        display_raw_data(df)

        restart = input('\nWould you like to restart? Enter yes or no.\n').lower()
        while restart not in ['yes','no']:
            restart = input('\nplease , you should choose yes or no. Would you like to restart? again\n').lower()
            if restart != 'yes':
                print ('Thank_you')
                time.sleep(4)
                break
        print ('Thank_you')
        time.sleep(4)
        break


if __name__ == "__main__":
	main()
