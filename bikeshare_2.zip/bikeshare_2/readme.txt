Prerequisite
	You must have installed python and libraries like numpy and pandas and matplotli.

To Run the project
	Open the terminal
	And run python bikeshare_2.py

These Links halped me solve the project
	https://github.com/pss2138/Udacity-Programming-for-Data-Science-with-Python-Project2

	https://github.com/ahmed-gharib89/bike-share-udacity-dpnd/blob/master/bikeshare_2.py#L73
