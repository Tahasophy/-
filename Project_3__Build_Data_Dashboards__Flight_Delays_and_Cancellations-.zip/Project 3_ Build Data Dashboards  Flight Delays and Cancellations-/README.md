In this project I have created Number of visualizations using Tableau to reveal insights from the Flight Delays and Cancellations data set. 

This data comes from a Kaggle dataset, it tracks the on-time performance of US domestic flights operated by large air carriers in 2015.

Link:  https://www.kaggle.com/usdot/flight-delays/data

https://public.tableau.com/app/profile/taha4323/viz/project_16436936951140/CancellationMap?publish=yes

https://public.tableau.com/app/profile/taha4323/viz/project2_16436948593810/CancellationMap2?publish=yes

https://public.tableau.com/app/profile/taha4323/viz/project3_16436952881330/CancellationBars?publish=yes

https://public.tableau.com/app/profile/taha4323/viz/project4d/CancellaitonDashboard?publish=yes

https://public.tableau.com/app/profile/taha4323/viz/project5_16436968402900/CancelltaionReason?publish=yes

https://public.tableau.com/app/profile/taha4323/viz/project6_16436976281050/CancelltaionAirline?publish=yes

https://public.tableau.com/app/profile/taha4323/viz/project7_16436988877800/AirportDelay?publish=yes

https://public.tableau.com/app/profile/taha4323/viz/project8_16437000150850/CityCanceld?publish=yes

https://public.tableau.com/app/profile/taha4323/viz/project9s/CancellaitonStory?publish=yes


