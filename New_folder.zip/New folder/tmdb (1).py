#!/usr/bin/env python
# coding: utf-8

# # Project: Investigate a Dataset (TMDb Movie Dataset)

# # by Taha Sobhi

# # Table of Contents

# Introduction
# 
# Data Wrangling
# 
# Exploratory Data Analysis
# 
# Conclusions
# 
# Limitations

# # Introduction

# TMDb movie data set contains information about 10,000 movies collected from The Movie Database (TMDb), including user ratings and revenue.I would like to find other intresting patterns in the dataset.

# # data set Contain:

# Total Rows = 10866 Total Columns = 21 After Seeing the dataset we can say that some columns is contain null values

# # Questions

# 1-Which year has the highest release of movies?
# 
# 2-Which Month Released Highest Number Of Movies In All Of The Years?
# 
# 3-Which Genre Has The Highest Release Of Movies?
# 
# 4-Which Average Votes Distribution?
# 
# 5-Which Movie with Largest And Lowest Earned Revenue?
# 
# 6-Most Frequent star cast?
# 
# 7-Which What properties are associated with highly rated movies?
# 
# 8-Movie with Highest And Lowest Budget?
# 
# Which length movies most liked by the audiences according to their popularity?
# 
# How Does Popularity Depends On Profit?
# 
# Correlations

# In[69]:



#   plan to use.

# Remember to include a 'magic word' so that your visualizations are plotted
#   inline with the notebook. See this page for more:
#   http://ipython.readthedocs.io/en/stable/interactive/magics.html
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import operator


# # Data Wrangling

# Tip: In this section of the report, you will load in the data, check for cleanliness, and then trim and clean your dataset for analysis. Make sure that you document your steps carefully and justify your cleaning decisions.
# 

# # General Properties

# In[70]:


# Load your data and print out a few lines. Perform operations to inspect data
#   types and look for instances of missing or possibly errant data.
df=pd.read_csv('tmdb-movies.csv')
df.head()


# In[71]:


df.info()


# In[72]:


df.describe()


# In[73]:


#data has null values so we count total rows in each column which contain null values
df.isnull().sum()


# In[74]:


#fill the null values with zero using 'fillna' function
df1=df.fillna(0)


# Tip: You should not perform too many operations in each cell. Create cells freely to explore your data. One option that you can take with this project is to do a lot of explorations in an initial notebook. These don't have to be organized, but make sure you use enough comments to understand the purpose of each code cell. Then, after you're done with your analysis, create a duplicate notebook where you will trim the excess and organize your steps so that you have a flowing, cohesive report.
# 
# Tip: Make sure that you keep your reader informed on the steps that you are taking in your investigation. Follow every code cell, or every set of related code cells, with a markdown cell to describe to the reader what was found in the preceding cell(s). Try to make it so that the reader can then understand what they will be seeing in the following cell(s).
# 
# Data Cleaning (Removing the unused information from the dataset )

# Visualize the data by column to examine the data.

# In[75]:


df.hist(figsize = (10, 10));


# # Data Cleaning (Removing the unused information from the dataset )

# In[76]:


get_ipython().run_line_magic('config', 'IPCompleter.greedy=True')


# In[77]:


# After discussing the structure of the data and any problems that need to be
#   cleaned, perform those cleaning steps in the second part of this section.


# # 1-remove duplicate rows from the dataset

# In[78]:


#counting the duplicates 
sum(df1.duplicated())


# # Printing the Data's data type and dimensions

# The TMdb dataset consists of 10866 rows and 21 columns.

# In[79]:


#drop these duplicated rows 
df1.drop_duplicates(inplace=True)
df1.shape


# # 2- remove the unused colums that are not needes in the analysis process

# In[80]:


#The columns like imdb_id, homepage,tagline, overview, budget_adj and revenue_adj are not required for my analysis
#I will drop these columns
df1.drop(['imdb_id','homepage','tagline','overview','budget_adj','revenue_adj'],axis =1,inplace = True)


# In[81]:


df1.shape


# # 3- changing Datetime Format

# In[82]:


#the the given in the dataset is in string format.
#So we need to change this in datetime format
df1['release_date']=pd.to_datetime(df1['release_date'])
df1['release_date'].head()


# # Exploratory Data Analysis

# In this step, I will explore the data to answer the below question and plot different visualizations to identify patterns and dependencies.

# # Research Question 1:  Which year has the highest release of movies?

# In[83]:


#count the number of movies in each year 
data=df1.groupby('release_year').count()['id']


# In[84]:


data.plot(xticks = np.arange(1960,2016,5))
sns.set(rc={'figure.figsize':(14,5)})
plt.title("Year Vs Number Of Movies",fontsize = 14)
plt.xlabel('Release year',fontsize = 13)
plt.ylabel('Number Of Movies',fontsize = 13)
#set the style sheet
sns.set_style("whitegrid")


# After Seeing the plot and the output we can conclude that year 2014 year has the highest release of movies (700) followed by year 2013 (659) and year 2015 (629).

# # Research Question 2: Which Month Released Highest Number Of Movies In All Of The Years?

# In[85]:


number_of_release=df1['release_date'].dt.month.value_counts().sort_index()
number_of_release


# In[86]:


months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
number_of_release = pd.DataFrame(number_of_release)
number_of_release['month'] = months
#change the column name of the new dataframe 'number_of_release'
number_of_release.rename(columns = {'release_date':'number_of_release'},inplace=True)

number_of_release.plot(x='month',kind='bar',fontsize = 11,figsize=(8,6))
#set the labels and titles of the plot.
plt.title('Months vs Number Of Movie Releases',fontsize = 15)
plt.xlabel('Month',fontsize = 13)
plt.ylabel('Number of movie releases',fontsize = 13)


# According to the plot we can conclude that there are higher number of release in september and october month.

# # Research Question 3: Which Genre Has The Highest Release Of Movies?

# In[87]:


#make a function will will split the string and return the count of each genre.
def data(x):
    #concatenate all the rows of the genrs.
    data_plot = df[x].str.cat(sep = '|')
    data = pd.Series(data_plot.split('|'))
    #conts each of the genre and return.
    info = data.value_counts(ascending=False)
    return info


# In[88]:


total_genre_movies = data('genres')
print(total_genre_movies)


# # Research Question 4: Average Votes Distribution

# Let's move to somewhere else. There is some curiosity about the movies' average votes. Lets see their distribution. The following code creates a boxplot which illustrates their mean which is about 6. Also two plots were created; one with the distribution of the ratings from 1960 to 2015 and another with the ratings distribution from by year.

# In[90]:


#####
#movie ratings' distribution all over the years
#####

sns.set(rc={'figure.figsize':(10,10)}, font_scale=1.1)

temp_df = df[["vote_average"]]


sns.set_style("whitegrid")
ax = sns.distplot(temp_df.vote_average)

ax = sns.boxplot(x = temp_df.vote_average)

ax.set(xlabel='average votes', title = 'average votes distribution')
plt.show()


# # Question 4.1: Ratings Distribution by Year

# The previous question shows that the mean of the ratings all over these years (1960 - 2015) are almost 6. What about the ratings at a specific year. The following snippet code creates a plot showing the ratings distributions per year.

# In[91]:


#####
#movie ratings' distributions per year
#####

sns.set(rc={'figure.figsize':(15,15)}, font_scale=1.3)

temp_df = df[["release_year", "vote_average"]]


sns.set_style("whitegrid")
ax = sns.violinplot(x = temp_df.vote_average, y = temp_df.release_year, orient ="h")

ax.set(xlabel='movie ratings distributions', ylabel='years', title = 'movie ratings distributions per year')
plt.show()


# The previous figure illustrates that all the years have mean ratings about 6 to 6.5. However some exclusions such as the year 1974 has mean ratings around 7. It seems that during that time great movies with high impact on the crowd were produced.

# # Research Question 5 : Movie with Largest And Lowest Earned Revenue?

# In[92]:


def find_minmax(x):
    #use the function 'idmin' to find the index of lowest profit movie.
    min_index = df1[x].idxmin()
    #use the function 'idmax' to find the index of Highest profit movie.
    high_index = df1[x].idxmax()
    high = pd.DataFrame(df1.loc[high_index,:])
    low = pd.DataFrame(df1.loc[min_index,:])
    
    #print the movie with high and low profit
    print("Movie Which Has Highest "+ x + " : ",df1['original_title'][high_index])
    print("Movie Which Has Lowest "+ x + "  : ",df1['original_title'][min_index])
    return pd.concat([high,low],axis = 1)


# In[93]:


find_minmax('revenue')


# In[94]:


#top 10 movies which made highest revenue.
#sort the 'revenue' column in decending order and store it in the new dataframe.
info = pd.DataFrame(df1['revenue'].sort_values(ascending = False))
info['original_title'] = df1['original_title']
data = list(map(str,(info['original_title'])))

#extract the top 10 movies with high revenue data from the list and dataframe.
x = list(data[:10])
y = list(info['revenue'][:10])

#make the point plot and setup the title and labels.
ax= sns.barplot(x=y,y=x)
sns.set(rc={'figure.figsize':(12,5)})
ax.set_title("Top 10 High Revenue Movies",fontsize = 20)
ax.set_xlabel("Revenue",fontsize = 13)
ax.set_ylabel("movie",fontsize = 13)

sns.set_style("darkgrid")


# As we can see that 'Avatar' movie earn the highest profit in all, making over 2.5B in profit in this dataset.And the most in loss movie in this dataset is The Wild Card.
# 
# 

# # Research Question 6: Most Frequent star cast?

# In[98]:


#plot a 'bar' plot using plot function for 'genre vs number of movies'.
total_genre_movies.plot(kind= 'bar',figsize = (13,8),fontsize=12)
#setup the title and the labels of the plot.
plt.title("Genre With Highest Release",fontsize=15)
plt.xlabel('Number Of Movies',fontsize=13)
plt.ylabel("Genres",fontsize= 13)


# According to the plot Drama(4761) genre has the highest release of movies followed by Comedy(3793) and Thriller(2908).

# # Research Question 7: What properties are associated with highly rated movies?

# There are two rows that can be used to understand the favorability of a movie, 'popularity' and 'vote_average'. I compare these columns with each other to identify which one will be more helpful in answering my question.

# In[99]:


df.plot(x='vote_average', color = 'r',y='popularity',kind='scatter')
plt.title('Vote Average vs Popularity')
plt.show()


# In[100]:


df['vote_average'].plot(kind='box')
plt.show()


# In[101]:


df['popularity'].plot(kind='box')
plt.show()


# I want to first check to make sure that both 'popularity' and 'vote_average' represent the same thing. The scatter plot above illustrates that both columns are positively correlated. However, as shown by the box plots, 'vote_average' is more evenly distributed and lacks any outliers. Therefore, all following analysis will be done with 'vote_average'.

# # Research Question8: Movie with Highest And Lowest Budget?

# In[102]:


#use 'find_minmax' function which i made earlier.
#make sure that movie with budget zero didn't affect the result.
#so change the zero into NAN in budget column.
df1['budget'] = df1['budget'].replace(0,np.NAN)
find_minmax('budget')


# In[103]:


#make a plot which contain top 10 highest budget movies.
#sort the 'budget' column in decending order and store it in the new dataframe.
info = pd.DataFrame(df1['budget'].sort_values(ascending = False))
info['original_title'] = df1['original_title']
data = list(map(str,(info['original_title'])))

#extract the top 10 budget movies data from the list and dataframe.
x = list(data[:10])
y = list(info['budget'][:10])

#plot the figure and setup the title and labels.
ax = sns.barplot(x=y,y=x)
sns.set(rc={'figure.figsize':(12,5)})
ax.set_title("Top 10 High Budget Movies",fontsize = 15)
ax.set_xlabel("Budget",fontsize = 13)
ax.set_ylabel("movie",fontsize = 13)
sns.set_style("darkgrid")


#  As we can see that the Movie Which Has Highest budget is The Warrior's Way and the Movie Which Has Lowest budget is harry potter and the half-blood prince.

# # Research Question9: Which length movies most liked by the audiences according to their popularity?

# In[104]:


#make the group of the data according to their runtime and find the mean popularity related to this and plot.
df1.groupby('runtime')['popularity'].mean().plot(figsize = (13,5),xticks=np.arange(0,1000,100))

#setup the title of the figure
plt.title("Runtime Vs Popularity",fontsize = 14)
plt.xlabel('Runtime',fontsize = 13)
plt.ylabel('Average Popularity',fontsize = 13)
#setup the figure size.
sns.set(rc={'figure.figsize':(15,8)})
sns.set_style("whitegrid")


# According to the plot we can say that movies in the range of 100-200 runtime are more popular than other runtime movies. Because it is boring to see the long duration movies.

# # Reasearch Question 10: How Does Popularity Depends On Profit?

# In[105]:


df1['Profit'] = df1['revenue'] - df1['budget']

ax = sns.regplot(x=df1['popularity'],y=df1['Profit'],color='c')

#setup the title and the labels of the scatter plot.
ax.set_title("Popularity Vs Profit",fontsize=13)
ax.set_xlabel("Popularity",fontsize=12)
ax.set_ylabel("Profit",fontsize=12)

#setup the figure size.
sns.set(rc={'figure.figsize':(6,4)})
sns.set_style("whitegrid")

#find the correlation between them.
data_corr = df1.corr()

print("Correlation Between Popularity And Profit : ",data_corr.loc['popularity','Profit'])


# as we see Popularity and profit have positive correlation(0.61). It means that movie with high popularity tends to earn high profit.

# #  Reasearch Question 11: Correlations

# This section deals with the correlations, where we were looking at the top  movies based on some characteristics (adjusted revenue, adjusted budget, and average votes). We were expecting that regardless the features the top movies would be the same. However this notion did not appear. So to investigate it even more scatterplots and correlations between the adjusted revenue, the adjusted budget, movies and vote average were produced. The code below produce scatterplots with pairs of these 4 variables.

# In[106]:


#####
#correlation plots
#####

#get
aux_df = df[['revenue_adj', 'budget_adj', 'popularity', 'vote_average']]

sns.set(rc={'figure.figsize':(15,15)}, font_scale=1.3, style="ticks")


f1 = sns.jointplot(x = "budget_adj", y = "revenue_adj", kind = "scatter", data = aux_df)
f1.fig.suptitle('scatterplot and correlation for budget_adj and revenue_adj')

f2 = sns.jointplot(x = "budget_adj", y = "popularity", kind = "scatter", data = aux_df)
f2.fig.suptitle('scatterplot and correlation for budget_adj and popularity')
f3 = sns.jointplot(x = "budget_adj", y = "vote_average", kind = "scatter", data = aux_df)
f3.fig.suptitle('scatterplot and correlation for budget_adj and vote_average')

f4 = sns.jointplot(x = "revenue_adj", y = "popularity", kind = "scatter", data = aux_df)
f4.fig.suptitle('scatterplot and correlation for revenue_adj and popularity')
f5 = sns.jointplot(x = "revenue_adj", y = "vote_average", kind = "scatter", data = aux_df)
f5.fig.suptitle('scatterplot and correlation for revenue_adj and vote_average')

f6 = sns.jointplot(x = "popularity", y = "vote_average", kind = "scatter", data = aux_df)
f6.fig.suptitle('scatterplot and correlation for popularity and vote_average')


# According to pearson coefficient there is a positive correlation between the adjasted revenue, adjasted budget and popularity. Moroever there is a weak positive correlation between the average votes with the other 3 variables (adjasted revenue, adjasted budget and popularity)

# If we want to see all these relations in a single plot, seaborn's pairplot can provide this functionality

# In[107]:


f1 = sns.pairplot(aux_df, kind="reg", diag_kind="kde", diag_kws=dict(shade=True))
f1.fig.suptitle('scatterplots for budget_adj, revenue_adj, popularity and vote_average\n')
f1.fig.tight_layout(rect=[0, 0.03, 1, 0.95])


# # Conclusions

# 1-year 2014 year has the highest release of movies (700) followed by year 2013 (659) and year 2015 (629).
# 
# 2-the higher number of release in september and october month.
# 
# 3-Drame, Comedy, Thriller and Action are four most-made genres.
# 
# 4-'Avatar' movie earn the highest profit in all, making over 2.5B in profit in this dataset.And the most in loss movie in this dataset is The Warrior's Way.
# 
# 5-the Movie Which Has Highest budget is The Warrior's Way and the Movie Which Has Lowest budget is Fear Clinic.
# 
# 6-we can say that movies in the range of 100-200 runtime are more popular than other runtime movies. Because it is boring to see the long duration movies.
# 
# 7-movie with high popularity tends to earn high profit.

# # Limitations:

# we are not sure if the data provided to us is completel corect and up-to-date.the budget and revenue column do not have currency unit, it might be possible different movies have budget in different currency according to the country they are produce in. So a disparity arises here which can state the complete analysis wrong. i want to Drop the rows with missing values but it will affecte the overall analysis.During the data cleaning process, I split the data seperated by '|' into lists for easy parsing during the exploration phase. This increases the time taken in calculating the result.
