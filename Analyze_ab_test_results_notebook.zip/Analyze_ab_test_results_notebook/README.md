# Analyze A/B Results

Udacity Data Analytics Nanodegree January 2022 Project 2 Analyze A/B Results 

# Project Details
For this project, I will be working to understand the results of an A/B test run by an e-commerce website. The goal is to work through this notebook to help the company understand if they should implement the new page, keep the old page, or perhaps run the experiment longer to make their decision.

# Project Specifications
## Code Quality 
- All code cells can be run without error.
- Docstrings, comments, and variable names enable the readability of the code.

## Statistical Analyses
- All results from different analyses are correctly interpreted.
- For all numeric values, you should provide the correct results of the analysis.
- Conclusions should include not only statistical reasoning but also practical reasoning for the situation.

##These Links helped me solve the project:

- https://github.com/latinacode/Analyze-A-B-Results/blob/master/Analyze_ab_test_results_notebook.ipynb

- https://github.com/Abhishek20182/Analyze-AB-Test-Results/blob/master/Analyze_ab_test_results_notebook.ipynb

- https://github.com/amiratantawy/Project3----Analyze-A-B-Test-Results/blob/3878dea6574f873711e54b7d94412365c3d8093a/Analyze_ab_test_results_notebook.ipynb
